const express = require('express');
const variatControllers = require("../controllers/variatControllers.js");
const router = express.Router();


//get all variants
router.route("/getAllVariants").get(variatControllers.getAllVariants)
//get variant by id
router.route("/getVariantById/:id").get(variatControllers.getVariantById)
//create new variant
router.route("/createVariant").post(variatControllers.createVariant)
//update variant
router.route("/updateVariantById/:id").put(variatControllers.updateVariantById)
//delete variant
router.route("/deleteById/:id").delete(variatControllers.deleteVariantById)


module.exports = router;